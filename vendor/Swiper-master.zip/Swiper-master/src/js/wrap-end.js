    window.Swiper = Swiper;
})();