
    // Return swiper instance
    return s;
};
