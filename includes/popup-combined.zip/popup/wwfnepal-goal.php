		<img src="img/wwfnepal/about-wwf-nepal<?php echo get_small_image();?>.jpg" class="hidden">
    	<div id="" class="article-section" style="background-image: url('img/wwfnepal/about-wwf-nepal<?php echo get_small_image();?>.jpg'); height: 100%; width: 100%; top: 0; left: 0; z-index: 999;">            
        <div class="section-intro content-txt section-absolute">
          
        </div> <!-- /.section-intro -->
    	</div>