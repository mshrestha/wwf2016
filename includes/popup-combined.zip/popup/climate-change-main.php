<div id="climate-change-main-popup" class="popup-wrap scrollbar-outer-div" style="position: fixed; height: 100%; width: 100%;top: 0; left: 0; z-index: 999;">	
    <div class="scrollbar-inner-div">
        <div class="scrollbar-div">
		  	<?php
		    popup_navigation();
		    ?>

			<?php include('includes/popup/climate-change-participation.php');?>
			<?php include('includes/popup/climate-change-building-community.php');?>
			<?php include('includes/popup/climate-change-alternate-energy.php');?>
			<?php include('includes/popup/climate-change-building-capacities.php');?>
			<?php include('includes/popup/climate-change-permanent.php');?>
		</div>
	</div>
</div>