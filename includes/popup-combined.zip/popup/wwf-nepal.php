    	
        <div id="wwf-nepal-popup" class="popup-wrap scrollbar-outer-div" style="background-image: url('img/wwfnepal/about-wwf-nepal.jpg'); height: 100%; width: 100%; position: fixed;top: 0; left: 0; z-index: 999;">            
            <div class="scrollbar-inner-div">
                <div class="scrollbar-div">
                    <?php
                    popup_navigation();
                    ?>

                    <?php 
                    include('includes/popup/wwfnepal-about.php');
                    //include('includes/popup/wwfnepal-vision.php');
                    //include('includes/popup/wwfnepal-goal.php');
                    include('includes/popup/wwfnepal-regional-living.php');
                    include('includes/popup/wwfnepal-regional-tiger.php');
                    include('includes/popup/wwfnepal-regional-asian.php');
                    include('includes/popup/wwfnepal-acknowledgement.php');
                    ?>
                </div>
            </div>
    	</div>