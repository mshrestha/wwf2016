<div id="wildlife-main-popup" class="popup-wrap scrollbar-outer-div" style="position: fixed; height: 100%; width: 100%;top: 0; left: 0; z-index: 999;">	

    <div class="scrollbar-inner-div">
        <div class="scrollbar-div">
		  	<?php
		    popup_navigation();
		    ?>
			<?php
			include('includes/popup/wildlife-rhino-translocation.php');
			include('includes/popup/wildlife-snow-leopard-collaring.php');
			include('includes/popup/wildlife-zero-poaching.php');
			include('includes/popup/wildlife-swamp-deer-translocation.php');
			include('includes/popup/wildlife-reducing-human-wildlife-conflict.php');
			?>
		</div>
	</div>
</div>