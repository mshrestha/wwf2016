
    	<div id="" class="article-section" style="background-image: url('img/inner-pop-up-image-bg.jpg'); height: 100%; width: 100%; top: 0; left: 0; z-index: 999;">            
	        <div class="section-intro content-txt section-absolute">
	          <h1 class="uppercase">Regional Programs</h1>
	          <h1 class="uppercase">Living Himalayas Initiative</h1>
	          <p>WWF’s work in Nepal is part of Living Himalayas – WWF’s global initiative, which aims to bring the three governments of Bhutan, India and Nepal together to effectively manage and conserve the natural resources in the face of climate change for the sake of their unique people, their exceptional wildlife and their breath-taking environment. Combining connectivity and regional solutions, the initiative views the eco-region as a single unit and not a series of fragmented landscapes in separate countries. Wildlife trade, landscape management and development issues will be treated regionally, bringing people, government and industry together in the three countries and developing plans that straddle borders and landscapes.</p>
	        </div> <!-- /.section-intro -->
    	</div>