<div id="policy-main-popup" class="popup-wrap scrollbar-outer-div" style="position: fixed; height: 100%; width: 100%;top: 0; left: 0; z-index: 999;">	
    <div class="scrollbar-inner-div">
        <div class="scrollbar-div">
		  	<?php
		    popup_navigation();
		    ?>

			<?php 
			include('includes/popup/policy-chal-strategy.php');
			include('includes/popup/policy-tal-nepal.php');
			?>
		</div>
	</div>
</div>