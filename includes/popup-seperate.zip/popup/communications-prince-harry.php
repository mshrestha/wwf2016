
    	<div id="communications-prince-harry-popup" class="popup-wrap " style="background-image: url('img/communications/prince-harry.jpg'); height: 100%; width: 100%; position: fixed;top: 0; left: 0; z-index: 999;">
            <?php
            $popup_communications_section_current = 2;
            
            popup_navigation($popup_communications_section[$popup_communications_section_current-1], $popup_communications_section[$popup_communications_section_current+1]);
            ?>
    		<div class="container-fluid fluid-fixed">
    			<div class="col-sm-6 col-md-5 col-sm-offset-1">
    				<div class="section-intro content-txt">
	    				<h1 class="uppercase">Prince Harry</h1>
	    				<p>WWF Nepal was honored to host Prince Harry on 21 March in Bardia as part of his five-day visit to Nepal. A major highlight of the program was Prince Harry’s visit to Dalla village in Khata Corridor where Prince Harry visited the homestay program that is providing conservation incentives to local communities, and got to understand the biogas project that provides local households with alternate energy access, and the broader conservation activities underway in this critical corridor that links Nepal’s Bardia National Park with India’s Katerniaghat Wildlife Sanctuary. In a parting note at the army headquarters in Bardia, Prince Harry wrote: "I congratulate every single one of you for what you have achieved here. Working together has proved itself, and no rhinos poached for three years is near perfection. Well done all of you. Thank you from all of us who care for all these amazing animals and the habitat they live in."</p>
    				</div> <!-- /.section-intro -->
    			</div>
    		</div> <!-- /.container-fluid fuild-fixed -->
    	</div>