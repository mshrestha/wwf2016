
    	<div id="communications-tiger-day-popup" class="popup-wrap " style="background-image: url('img/communications/global-tiger-day.jpg'); height: 100%; width: 100%; position: fixed;top: 0; left: 0; z-index: 999;">
            <?php
            $popup_communications_section_current = 4;
            
            popup_navigation($popup_communications_section[$popup_communications_section_current-1], $popup_communications_section[$popup_communications_section_first]);
            ?>
    		<div class="container-fluid fluid-fixed">
    			<div class="col-sm-6 col-md-5 col-sm-offset-1">
    				<div class="section-intro content-txt">
	    				<h1 class="uppercase">Global Tiger Day </h1>
	    				<p>With tigers as the muse and Global Tiger Day a platform, WWF Nepal’s The Generation Green campaign brought together more than 1,000 young minds through a variety of events to bring out their interpretations of tigers and their protection. In the lead up to 29 July, youth participated in four different events centered on tigers. These included an inter-college debating league and art challenge, a creative writing contest, and a social media-driven creative slogan challenge. On Global Tiger Day, an open mic event was organized to add to the celebrations giving the young participants a three-minute window to perform for tigers. From beatboxing to contemporary dance, a special song penned for tigers and a magic show dedicated to the iconic species, the creativity of Nepal’s youth soared with their roar…all for the sake of the endangered tiger.</p>
    				</div> <!-- /.section-intro -->
    			</div>
    		</div> <!-- /.container-fluid fuild-fixed -->
    	</div>