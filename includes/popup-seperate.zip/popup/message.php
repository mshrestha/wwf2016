
    	<div id="message-popup" class="popup-wrap " style="background-image: url('img/inner-pop-up-image-bg.jpg'); height: 100%; width: 100%; position: fixed;top: 0; left: 0; z-index: 999;">
            <?php
            popup_navigation();
            ?>
    		<div class="container-fluid fluid-fixed">
    			<div class="col-sm-6 col-md-5 col-sm-offset-1">
    				<div class="section-intro content-txt">
	    				<h1 class="uppercase">MESSAGE FROM THE COUNTRY REPRESENTATIVE</h1>
                        <p>&lt;TO BE COMPLETED&gt;</p>	    				
    				</div> <!-- /.section-intro -->
    			</div>
    		</div> <!-- /.container-fluid fuild-fixed -->
    	</div>