						<div class="swiper-slide" data-hash="slide-home">
	        		<div class="container-fluid fluid-fixed">
		                <div class="text intro-text" data-swiper-parallax="-300">
		                	<div class="box-title">
		                		<div class="inner-title">
		                			<p>WWF works to conserve nature and ecological processes through a combination of actions on the ground, national and international advocacy work to establish appropriate policies, and international campaigns to highlight and demonstrate solutions to crucial environmental problems.</p>	
		                		</div>
		                	</div>
		                </div>
	                </div>
	            </div> <!-- intro slide .swiper-slide end -->